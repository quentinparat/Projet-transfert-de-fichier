## mjml-html

```xml
<mjml>
  <mj-body>
    <mj-container>
      <mj-html>
        <!-- Your html goes here -->
      </mj-html>
    </mj-container>
  </mj-body>
</mjml>
```

<aside class="warning">
  This component will soon be <b>deprecated</b>. As you can use HTML inside `mj-text` and `mj-raw`, `mj-html` has no real added value.
</aside>
