import Carousel from './Carousel'
import CarouselImage from './CarouselImage'

export default { Carousel, CarouselImage }
