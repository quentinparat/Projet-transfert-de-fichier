import Hero from './Hero'
import HeroContent from './HeroContent'

export default { Hero, HeroContent }
