export default [{
  name: 'Open Sans',
  url: 'https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,700'
}, {
  name: 'Droid Sans',
  url: 'https://fonts.googleapis.com/css?family=Droid+Sans:300,400,500,700'
}, {
  name: 'Lato',
  url: 'https://fonts.googleapis.com/css?family=Lato:300,400,500,700'
}, {
  name: 'Roboto',
  url: 'https://fonts.googleapis.com/css?family=Roboto:300,400,500,700'
}, {
  name: 'Ubuntu',
  url: 'https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700'
}]
