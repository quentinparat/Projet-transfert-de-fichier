export const startConditionalTag = '<!--[if mso | IE]>'
export const endConditionalTag = '<![endif]-->'
export const startNegationConditionalTag = '<!--[if !mso | IE]><!-->'
export const endNegationConditionalTag = '<!--<![endif]-->'
