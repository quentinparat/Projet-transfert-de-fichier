### MJML monorepo

This is the list of official MJML packages. For various reasons, it is split in multiple folders, each with a `package.json`.
You can read more about the monorepo design [here](https://developer.atlassian.com/blog/2015/10/monorepos-in-git/)

If you want to contribute to one of the packages, please make sure to add documentation to the dedicated `README.md`
