import Navbar from './Navbar'
import InlineLinks from './InlineLinks'
import Link from './Link'

export default { Navbar, InlineLinks, Link }
