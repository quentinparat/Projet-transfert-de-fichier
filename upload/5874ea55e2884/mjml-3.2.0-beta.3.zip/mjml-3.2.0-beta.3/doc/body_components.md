# Standard Body components

MJML comes out of the box with a set of standard components to help you build easily your first templates without having to reinvent the wheel.
