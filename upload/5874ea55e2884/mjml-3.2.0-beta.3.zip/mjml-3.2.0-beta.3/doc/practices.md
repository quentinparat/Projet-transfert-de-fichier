
# MJML Guidelines

## Columns

Columns should be considered as block of content.

 - They should never be empty
 - Columns cannot contain sub-sections or columns yet

## Sections
